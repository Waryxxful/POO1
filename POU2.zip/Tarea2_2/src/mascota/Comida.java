package src.mascota;

public class Comida extends Item {

    public Comida(Integer id, Integer cantidad, String nombre, String clase) {
        super.setId(id);
        super.setCantidad(cantidad);
        super.setNombre(nombre);
        super.setClase(clase);
    }

    public void usar_item(Mascota mascota) {
        mascota.setEnergia(mascota.getEnergia() + 20);
        mascota.setSalud(mascota.getSalud() + 20);
        setCantidad(getCantidad() - 1);
    }

    public void printItemAplicado() {
        System.out.println("Dando de comer " + getNombre());
        System.out.println("");
        System.out.println("");
    }
}
