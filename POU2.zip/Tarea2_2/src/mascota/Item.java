package src.mascota;

public abstract class Item {
    private Integer id;
    private Integer cantidad;
    private String nombre;
    private String clase;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCantidad() {
        return this.cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClase() {
        return this.clase;
    }

    public void setClase(String clase) {
        this.clase = clase;
    }
    // getters y setters--------------------

    public abstract void printItemAplicado();

    public abstract void usar_item(Mascota mascota);
}
