package src.mascota;

public class Medicina extends Item {
    public Medicina(Integer id, Integer cantidad, String nombre, String clase) {
        super.setId(id);
        super.setCantidad(cantidad);
        super.setNombre(nombre);
        super.setClase(clase);
    }

    public void usar_item(Mascota mascota) {
        mascota.setSalud((mascota.getSalud() + 40));
        setCantidad(getCantidad() - 1);
    }

    public void printItemAplicado() {
        System.out.println("Aplicando medicamento " + getNombre());

    }
}
