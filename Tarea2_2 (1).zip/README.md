## Requerimientos

Necesita tener Java instalado.

## Estructura

La estructura de las carpetas es la siguiente:

- `src`: carpeta con los archivos.java
- `lib`: carpeta con las librerías java
- `img`: carpeta con las imagenes para el programa

## Ejecución del programa

- Para ejecutar el programa debe ir a una consola cmd e escribir "make all" (en cmd requerirá tener Mingw32 instalado y configurado el path del make)

## Limpiar .class

- Para limpiar los .class solo escriba en la consola "make clean"

## Extra

- El programa tiene para leer URL de imagenes para que pueda utilizar una mascota personalizada, solo deberá ir al Makefile y en "CONFIG_FILE" agregar la URL despues de "config.csv"
