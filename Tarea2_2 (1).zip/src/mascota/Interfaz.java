package src.mascota;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Interfaz extends Application {
    private Label estadoLabel;
    private Timeline timeline;
    private boolean inplay = false;
    private boolean dormido = false;

    public void start(Stage primaryStage) throws Exception {

        // Lectura del csv
        Parameters params = getParameters();
        Scanner in = new Scanner(new File(params.getRaw().get(0)));
        String urlImagenMascota = params.getRaw().size() > 1 ? params.getRaw().get(1) : null;
        Mascota mascota = new Mascota(in.nextLine());
        Inventario inventario = new Inventario();

        SimpleDoubleProperty salud = new SimpleDoubleProperty(mascota.getSalud() / 100);
        SimpleDoubleProperty energia = new SimpleDoubleProperty(mascota.getEnergia() / 100);
        SimpleDoubleProperty felicidad = new SimpleDoubleProperty(mascota.getFelicidad() / 100);

        String[] linea = in.nextLine().split(";");
        ArrayList<Button> jugueteButton = new ArrayList<Button>();
        ArrayList<HBox> alimentoButton = new ArrayList<HBox>();
        ArrayList<HBox> medicinaButton = new ArrayList<HBox>();
        Integer ind_alimento = 0;
        Integer ind_medicina = 0;

        // Llenar el inventario y asociar cada objeto con su respectivo botón
        for (; linea != null;) {
            if ((in.hasNext()) && (linea[1].equals("Juguete"))) {
                jugueteButton.add(crear_juguete(linea[3]));
                inventario.Agregar_Objeto(Integer.valueOf(linea[0]), 1, linea[2], linea[1]);
            } else {
                if (linea[1].equals("Alimento")) {
                    alimentoButton.add(crear_alimento(linea[3], linea[2]));
                } else if (linea[1].equals("Medicina")) {
                    medicinaButton.add(crear_medicina(linea[3], linea[2]));
                }
                inventario.Agregar_Objeto(Integer.valueOf(linea[0]), Integer.valueOf(linea[3]), linea[2], linea[1]);
            }

            if (in.hasNext()) {
                linea = in.nextLine().split(";");
            } else {
                linea = null;
                in.close();
            }
        }

        // Acción al hacer clic en un medicamento
        for (HBox medicinaBox : medicinaButton) {
            Button medicamentoButton = (Button) medicinaBox.getChildren().get(1);
            Label cantidadLabel = (Label) medicinaBox.getChildren().get(0);
            String nombreMedicina = medicamentoButton.getText();
            Medicina medicinaItem = null;

            for (Item item : inventario.getInventario()) {
                if (item instanceof Medicina && item.getNombre().equals(nombreMedicina)) {
                    medicinaItem = (Medicina) item;
                    break;
                }
            }
            final Medicina finalMedicinaItem = medicinaItem;

            if (finalMedicinaItem != null && finalMedicinaItem.getCantidad() > 0) {
                medicamentoButton.setOnAction(e -> {
                    if (inplay) {
                        finalMedicinaItem.usar_item(mascota);
                        cantidadLabel.setText(String.valueOf(finalMedicinaItem.getCantidad()));
                        salud.setValue(mascota.getSalud() / 100);
                        energia.setValue(mascota.getEnergia() / 100);
                        felicidad.setValue(mascota.getFelicidad() / 100);
                        if (finalMedicinaItem.getCantidad() == 0) {
                            medicamentoButton.setDisable(true);
                        }
                        mascota.determinar_estado();
                        estadoLabel.setText(mascota.getEstado());
                    }
                });
            } else {
                medicamentoButton.setDisable(true);
            }
        }

        // Acción al hacer clic en una comida
        for (HBox alimentoBox : alimentoButton) {
            Button comidaButton = (Button) alimentoBox.getChildren().get(1);
            Label cantidadLabel = (Label) alimentoBox.getChildren().get(0);
            String nombreComida = comidaButton.getText();
            Comida comidaItem = null;

            for (Item item : inventario.getInventario()) {
                if (item instanceof Comida && item.getNombre().equals(nombreComida)) {
                    comidaItem = (Comida) item;
                    break;
                }
            }

            final Comida finalComidaItem = comidaItem;

            if (finalComidaItem != null && finalComidaItem.getCantidad() > 0) {
                comidaButton.setOnAction(e -> {
                    if (inplay) {
                        finalComidaItem.usar_item(mascota);
                        cantidadLabel.setText(String.valueOf(finalComidaItem.getCantidad()));
                        salud.setValue(mascota.getSalud() / 100);
                        energia.setValue(mascota.getEnergia() / 100);
                        felicidad.setValue(mascota.getFelicidad() / 100);
                        if (finalComidaItem.getCantidad() == 0) {
                            comidaButton.setDisable(true);
                        }
                        mascota.determinar_estado();
                        estadoLabel.setText(mascota.getEstado());
                    }
                });
            } else {
                comidaButton.setDisable(true);
            }
        }

        // Acción al hacer clic en un juguete
        for (Button juguete : jugueteButton) {
            juguete.setOnAction(e -> {
                if (inplay) {
                    int index = jugueteButton.indexOf(juguete);
                    Juguete jugueteItem = (Juguete) inventario.getInventario().get(index);
                    jugueteItem.usar_item(mascota);
                    System.out.println("Felicidad antes de actualizar barra: " + mascota.getFelicidad());
                    felicidad.setValue(mascota.getFelicidad() / 100.0);
                    mascota.determinar_estado();
                    estadoLabel.setText(mascota.getEstado());
                }
            });
        }

        // Creación de la interfaz

        // Menú
        MenuBar menuBar = new MenuBar();
        Menu menuInicio = new Menu("Inicio");
        Menu menuAcciones = new Menu("Acciones");
        Menu menuHelp = new Menu("Help");
        menuBar.getMenus().addAll(menuInicio, menuAcciones, menuHelp);

        // inicio
        MenuItem menuItemStart = new MenuItem("Iniciar");
        MenuItem menuItemReset = new MenuItem("Reiniciar");
        MenuItem menuItemClose = new MenuItem("Salir");
        menuInicio.getItems().addAll(menuItemStart, menuItemReset, menuItemClose);

        // Acciones
        MenuItem menuItemLuzon = new MenuItem("Prender Luz");
        MenuItem menuItemLuzoff = new MenuItem("Apagar Luz");
        menuAcciones.getItems().addAll(menuItemLuzon, menuItemLuzoff);

        // Help
        MenuItem menuItemAbout = new MenuItem("Acerca de");
        menuHelp.getItems().addAll(menuItemAbout);

        // Información máscota
        BorderPane zonaInfo = new BorderPane();
        zonaInfo.setPadding(new Insets(4));
        VBox info = new VBox(10);
        info.setPrefWidth(200);
        info.setStyle("-fx-background-color: lightblue;");
        Label name = new Label("Nombre:          " + mascota.getNombre());
        Label edad = new Label("Edad:               " + mascota.getEdad());
        Rectangle rectangle = new Rectangle(0, 0, 200, 5);
        info.getChildren().addAll(name, edad, rectangle);
        zonaInfo.setLeft(info);

        // Barra de propiedades

        // Salud
        Label saludLabel = new Label("Salud");
        saludLabel.setTextFill(Color.RED);
        saludLabel.setAlignment(Pos.CENTER);
        ProgressBar saludBar = new ProgressBar();
        saludBar.progressProperty().bind(salud);
        saludBar.setPrefWidth(200);
        saludBar.setPrefHeight(30);

        // Energía
        Label energiaLabel = new Label("Energia");
        energiaLabel.setTextFill(Color.GREEN);
        energiaLabel.setAlignment(Pos.CENTER);
        ProgressBar energiaBar = new ProgressBar();
        energiaBar.progressProperty().bind(energia);
        energiaBar.setPrefWidth(200);
        energiaBar.setPrefHeight(30);

        // Felicidad
        Label felicidadLabel = new Label("Felicidad");
        felicidadLabel.setTextFill(Color.BLUE);
        felicidadLabel.setAlignment(Pos.CENTER);
        ProgressBar felicidadBar = new ProgressBar();
        felicidadBar.progressProperty().bind(felicidad);
        felicidadBar.setPrefWidth(200);
        felicidadBar.setPrefHeight(30);

        // contenedor de las barras
        BorderPane zonaBarras = new BorderPane();
        zonaBarras.setPadding(new Insets(2));
        VBox barras = new VBox(10);
        barras.setPrefWidth(200);
        barras.setStyle("-fx-background-color: lightblue;");
        barras.setAlignment(Pos.CENTER);
        barras.getChildren().addAll(saludLabel, saludBar, energiaLabel, energiaBar, felicidadLabel, felicidadBar);
        zonaBarras.setLeft(barras);

        // Información máscota
        BorderPane zonaEstado = new BorderPane();
        zonaEstado.setPadding(new Insets(4));
        VBox estado = new VBox(100);
        estado.setAlignment(Pos.CENTER);
        estado.setPrefWidth(200);
        estado.setStyle("-fx-background-color: lightblue;");
        Label estadoLabel = new Label("Estado");
        estadoLabel.setStyle("-fx-font-size: 20px;");
        this.estadoLabel = new Label(mascota.getEstado()); // Utiliza la variable de instancia
        this.estadoLabel.setStyle("-fx-font-size: 40px;");
        mascota.determinar_estado();
        estado.getChildren().addAll(estadoLabel, this.estadoLabel); // Utiliza la variable de instancia
        zonaEstado.setLeft(estado);

        // background
        ImageView background = new ImageView();
        background.setFitWidth(312);
        background.setFitHeight(312);
        background.setPreserveRatio(true);
        /*
         * Image backgroundImage = new
         * Image(getClass().getResourceAsStream("/background.png"));
         * Image backgroundImageoff = new
         * Image(getClass().getResourceAsStream("/sleep.jpg"));
         */
        Image backgroundImage = new Image(".\\img\\background.png");
        Image backgroundImageoff = new Image(".\\img\\backgroundOff.png");
        background.setImage(backgroundImage);

        // Mascota
        ImageView mascotaImageView = new ImageView();
        if (urlImagenMascota != null) {
            // Si se incluye url
            try {
                mascotaImageView.setFitWidth(32);
                mascotaImageView.setFitHeight(32);
                mascotaImageView.setPreserveRatio(true);
                mascotaImageView.setFitWidth(120);
                mascotaImageView.setFitHeight(112);
                Image mascotaImage = new Image(urlImagenMascota);
                mascotaImageView.setImage(mascotaImage);
                mascotaImageView.setTranslateY(-165);
            } catch (Exception e) {
                System.out.println("Error loading image from URL: " + e.getMessage());
            }
        } else {
            // si no se incluye url
            mascotaImageView.setFitWidth(64);
            mascotaImageView.setFitHeight(64);
            mascotaImageView.setPreserveRatio(true);
            // Image defaultMascotaImage = new
            // Image(getClass().getResourceAsStream("/mascota.png"));
            Image defaultMascotaImage = new Image(".\\img\\mascota.png");
            mascotaImageView.setImage(defaultMascotaImage);
            mascotaImageView.setTranslateY(-105);
        }
        // animacion
        TranslateTransition translateTransition = new TranslateTransition();
        Duration velo = Duration.seconds(10);
        translateTransition.setDuration(velo);
        translateTransition.setNode(mascotaImageView);
        translateTransition.setFromX(-120);
        translateTransition.setToX(120);
        translateTransition.setCycleCount(TranslateTransition.INDEFINITE);
        translateTransition.setAutoReverse(true);

        translateTransition.play();

        // contenedor de imagen
        VBox imageBox = new VBox();
        imageBox.setStyle("-fx-background-color: lightblue;");
        imageBox.getChildren().addAll(background, mascotaImageView);
        imageBox.setPrefWidth(500);
        imageBox.setPrefHeight(312);
        imageBox.setAlignment(Pos.CENTER);
        StackPane zonaBackground = new StackPane(imageBox);
        zonaBarras.setPadding(new Insets(2));

        // inventario
        VBox inVBox = new VBox(10);
        HBox textosBox = new HBox(160);
        inVBox.setAlignment(Pos.CENTER);
        inVBox.setStyle("-fx-background-color: lightblue;");
        Label inventarioInterfaz = new Label("Inventario");
        Label alimentos = new Label("Alimentos");
        Label medicinas = new Label("Medicinas");
        Label juguetes = new Label("juguetes");
        textosBox.setAlignment(Pos.CENTER);
        textosBox.getChildren().addAll(alimentos, medicinas, juguetes);
        inventarioInterfaz.setStyle("-fx-font-size: 14px;");
        Rectangle rectangle2 = new Rectangle(0, 0, 600, 1);

        // Tabla
        HBox container = new HBox(15);
        GridPane objetos = new GridPane();
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 4; col++) {
                StackPane cell = new StackPane();
                cell.setMinSize(100, 25);
                Rectangle border = new Rectangle(100, 35);
                HBox item = new HBox();
                if ((col == 0 || col == 1) && (ind_alimento < alimentoButton.size())) {
                    item = alimentoButton.get(ind_alimento);
                    ind_alimento++;
                } else if ((col == 2 || col == 3) && (ind_medicina < medicinaButton.size())) {
                    item = medicinaButton.get(ind_medicina);
                    ind_medicina++;
                }
                border.setFill(null);
                border.setStroke(Color.BLACK);
                cell.getChildren().addAll(border, item);
                objetos.add(cell, col, row);
            }
        }

        // Boton juguete
        container.getChildren().add(objetos);
        for (int i = 0; i < jugueteButton.size(); i++) {
            container.getChildren().add(jugueteButton.get(i));
        }
        inVBox.getChildren().addAll(inventarioInterfaz, rectangle2, textosBox, container);

        // base
        VBox baseV = new VBox(10);
        HBox baseH = new HBox(10);
        VBox middleBox = new VBox(10);
        middleBox.getChildren().addAll(zonaBackground, inVBox);
        VBox leftBox = new VBox(10);
        leftBox.getChildren().addAll(zonaInfo, zonaBarras, zonaEstado);
        baseH.getChildren().addAll(leftBox, middleBox);

        // paso del tiempo
        timeline = new Timeline(new KeyFrame(Duration.seconds(0.5), e -> {
            if (dormido) {
                mascota.setSalud(mascota.getSalud() + 2);
                mascota.setEnergia(mascota.getEnergia() + 20);
                mascota.setFelicidad(mascota.getFelicidad() + 2);
            } else {
                mascota.setSalud(mascota.getSalud() - 5);
                mascota.setEnergia(mascota.getEnergia() - 5);
                mascota.setFelicidad(mascota.getFelicidad() - 5);
            }
            mascota.setEdad(mascota.getEdad() + 0.5);
            salud.setValue(mascota.getSalud() / 100.0);
            energia.setValue(mascota.getEnergia() / 100.0);
            felicidad.setValue(mascota.getFelicidad() / 100.0);
            edad.setText("Edad:               " + mascota.getEdad());
            mascota.determinar_estado();
            updateAnimation(translateTransition, mascota.getEstado());
            this.estadoLabel.setText(mascota.getEstado());
            if (mascota.getSalud() <= 0 || mascota.getEnergia() <= 0 || mascota.getEdad() >= 15) {
                timeline.stop();
                inplay = false;
            }
        }));

        timeline.setCycleCount(Timeline.INDEFINITE);

        baseV.getChildren().addAll(menuBar, baseH);
        Scene scene = new Scene(baseV, 900, 700);
        primaryStage.setTitle("Mascota Virtual");
        primaryStage.setScene(scene);
        primaryStage.show();

        // acciones menu
        menuItemStart.setOnAction(e -> {
            timeline.play();
            inplay = true;
        });
        menuItemReset.setOnAction(e -> {
            inplay = false;
            timeline.stop();
            mascota.setEdad(0);
            mascota.setSalud(10);
            mascota.setEnergia(10);
            mascota.setFelicidad(10);
            salud.setValue(mascota.getSalud() / 100.0);
            energia.setValue(mascota.getEnergia() / 100.0);
            felicidad.setValue(mascota.getFelicidad() / 100.0);
            edad.setText("Edad:               " + mascota.getEdad());
            estadoLabel.setText(mascota.getEstado());
        });
        menuItemAbout.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Acerca de");
            alert.setHeaderText(null);
            alert.setContentText(
                    "Esta es una aplicacion de simulacion de mascotas.\n en el menu de inicio seleccione \"inicio\" para empezar la simulacion \n para reiniciar la simulacion seleccione \"reinicio\"");
            alert.showAndWait();
        });
        menuItemClose.setOnAction(e -> System.exit(0));
        menuItemLuzon.setOnAction(e -> {
            background.setImage(backgroundImage);
            dormido = false;
        });
        menuItemLuzoff.setOnAction(e -> {
            background.setImage(backgroundImageoff);
            dormido = true;
        });
        // Parent root = FXMLLoader.load(getClass().getResource("view.fxml"));

    }

    // funcion para crear un boton de juguete
    public Button crear_juguete(String imagen) {
        ImageView juguete_view = new ImageView();
        juguete_view.setFitWidth(32);
        juguete_view.setFitHeight(32);
        juguete_view.setPreserveRatio(true);
        Image juguete_img = new Image(imagen);
        juguete_view.setImage(juguete_img);
        Button temp_button = new Button("", juguete_view);
        return temp_button;
    }

    // funcion para crear un boton de alimento en la posicion correcta
    public HBox crear_alimento(String cantidad, String nombre) {
        HBox item = new HBox(10);
        item.setMinSize(100, 35);
        Button itemButton = new Button(nombre);
        itemButton.setPrefHeight(35);
        itemButton.setPrefWidth(60);
        itemButton.setTranslateX(25);
        Label itemLabel = new Label(cantidad);
        itemLabel.setTranslateX(20);
        itemLabel.setTranslateY(10);
        item.getChildren().addAll(itemLabel, itemButton);
        return item;
    }

    // funcion para crear un boton de alimento en la posicion correcta
    public HBox crear_medicina(String cantidad, String nombre) {
        HBox item = new HBox(10);
        item.setMinSize(100, 35);
        Button itemButton = new Button(nombre);
        itemButton.setPrefHeight(35);
        itemButton.setPrefWidth(60);
        itemButton.setTranslateX(25);
        Label itemLabel = new Label(cantidad);
        itemLabel.setTranslateX(20);
        itemLabel.setTranslateY(10);
        item.getChildren().addAll(itemLabel, itemButton);
        return item;
    }

    // funcion para actualizar el valor de la velocidad de la animacion
    private void updateAnimation(TranslateTransition transition, String estado) {
        Duration velocidad;

        if (estado.equals("Feliz")) {
            velocidad = Duration.seconds(0.1);
        } else if (estado.equals("Neutro")) {
            velocidad = Duration.seconds(5);
        } else if (estado.equals("Muerto")) {
            velocidad = Duration.seconds(10000);
        } else {
            velocidad = Duration.seconds(10);
        }
        transition.setDuration(velocidad);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
