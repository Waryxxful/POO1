package src.mascota;

import java.util.ArrayList;

public class Inventario {
    private ArrayList<Item> inventario = new ArrayList<Item>();

    // Constructor vacío
    public Inventario() {

    }

    // Getter para obtener el inventario
    public ArrayList<Item> getInventario() {
        return this.inventario;
    }

    // Setter para establecer el inventario
    public void setInventario(ArrayList<Item> inventario) {
        this.inventario = inventario;
    }

    public void Agregar_Objeto(Integer id, Integer cantidad, String nombre, String clase) {
        if (clase.equals("Alimento")) {
            this.inventario.add(new Comida(id, cantidad, nombre, clase));
        } else if (clase.equals("Medicina")) {
            this.inventario.add(new Medicina(id, cantidad, nombre, clase));
        } else if (clase.equals("Juguete")) {
            this.inventario.add(new Juguete(id, nombre, clase));
        }

    }

    public void Eliminar_Objeto(Integer id) {
        if (id > 0 && id <= this.inventario.size()) {
            inventario.remove(id - 1); // Elimina el objeto en la posición indicada por id
            for (int i = 0; i < this.inventario.size(); i++) {
                this.inventario.get(i).setId(i + 1);
            }
        } else {
            System.out.println("ID fuera de rango");
        }
    }
}