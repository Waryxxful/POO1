package src.mascota;

public class Juguete extends Item {

    public Juguete(Integer id, String nombre, String clase) {
        super.setId(id);
        super.setCantidad(1);
        super.setNombre(nombre);
        super.setClase(clase);
    }

    public void usar_item(Mascota mascota) {
        mascota.setFelicidad(mascota.getFelicidad() + 30);
        setCantidad(getCantidad() - 1);
    };

    public void printItemAplicado() {
        System.out.println("Usando juguete " + getNombre());
        System.out.println("");
        System.out.println("");
    }
}
