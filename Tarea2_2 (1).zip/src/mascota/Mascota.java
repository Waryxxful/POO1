package src.mascota;

public class Mascota {
    private String nombre;
    private double edad;
    private double salud;
    private double energia;
    private double felicidad;
    private String estado;

    Mascota(String nombre) {
        this.nombre = nombre;
        this.edad = 0;
        this.salud = 10;
        this.energia = 10;
        this.felicidad = 10;
    }

    // getters y setters--------------------
    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getEdad() {
        return this.edad;
    }

    public void setEdad(double edad) {
        this.edad = edad;
    }

    public double getSalud() {
        return this.salud;
    }

    public void setSalud(double salud) {
        if ((getSalud()) > 100) {
            this.salud = 100;
        } else {
            this.salud = salud;
        }
    }

    public double getEnergia() {
        return this.energia;
    }

    public void setEnergia(double energia) {
        // Validamos que la energía no supere 100
        if ((getEnergia()) > 100) {
            this.energia = 100;
        } else {
            this.energia = energia;
        }
    }

    public double getFelicidad() {
        return this.felicidad;
    }

    public void setFelicidad(double felicidad) {
        // Validamos que la felicidad no supere 100
        if (felicidad > 100) {
            this.felicidad = 100;
        } else {
            this.felicidad = felicidad;
        }
    }

    public String getEstado() {
        return this.estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    // getters y setters--------------------

    public void determinar_estado() {
        if (getSalud() <= 0 || getEnergia() <= 0 || getEdad() >= 15) {
            setEstado("Muerto");
        } else if (getEnergia() <= 15) {
            setEstado("Cansado");
        } else if (getSalud() <= 30 && getEnergia() <= 30 && getEdad() >= 5) {
            setEstado("Enojado");
        } else if ((getSalud() <= 20 && getEdad() <= 5) || (getSalud() <= 50 && getEdad() <= 10 && getEdad() >= 5)) {
            setEstado("Hambriento");
        } else if ((getFelicidad() <= 20)) {
            setEstado("Triste");
        } else if ((getFelicidad() >= 60)) {
            setEstado("Feliz");
        } else {
            setEstado("Neutro");
        }
    }

    public void paso_del_tiempo() {
        if (getEdad() <= 5 && getSalud() <= 10) {
            setEnergia((getEnergia() - 5));
            setFelicidad((getFelicidad() - 20));
        } else if (getEdad() > 5 && getEdad() <= 10 && getSalud() <= 50) {
            setEnergia((getEnergia() - 10));
            setFelicidad((getFelicidad() - 20));
        } else if (getEdad() > 10 && getSalud() <= 50) {
            setEnergia((getEnergia() - 20));
            setFelicidad((getFelicidad() - 30));
        }
        setEdad((float) (getEdad() + 0.5));
        setSalud((getSalud() - 5));
    }

    public void dormir() {
        setEnergia(100);
        setFelicidad((getFelicidad() + 15));
        setSalud((getSalud() + 15));
    }

}
